import TerminalView from '../TerminalView'

export default function TerminalViewExample() {
  return (
    <div className="h-[600px]">
      <TerminalView />
    </div>
  )
}
