import SnakeGame from '../SnakeGame'

export default function SnakeGameExample() {
  return <SnakeGame />
}
