import OfferGenerator from '../OfferGenerator'

export default function OfferGeneratorExample() {
  return <OfferGenerator />
}
