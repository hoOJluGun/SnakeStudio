import RadioPlayer from '../RadioPlayer'

export default function RadioPlayerExample() {
  return <RadioPlayer />
}
