import CodeEditor from '../CodeEditor'

export default function CodeEditorExample() {
  return (
    <div className="h-[600px]">
      <CodeEditor />
    </div>
  )
}
